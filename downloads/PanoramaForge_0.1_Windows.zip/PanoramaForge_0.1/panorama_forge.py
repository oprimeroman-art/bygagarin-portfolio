#!/usr/bin/env python3
"""Panorama Forge — fully local browser UI and CLI for 360° panoramas."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import mimetypes
from pathlib import Path
import secrets
import threading
import traceback
import urllib.parse
import webbrowser

from PIL import Image
from engine import Settings, PanoramaError, enhance, make_preview, to_pano_rgb, locate_ai_exe

ROOT=Path(__file__).resolve().parent
WORKSPACE=ROOT/'workspace'
WORKSPACE.mkdir(exist_ok=True)
JOBS={}
LOCK=threading.Lock()
POOL=ThreadPoolExecutor(max_workers=1)
MAX_UPLOAD=95*1024*1024


def update_job(job_id,**changes):
    with LOCK:
        JOBS[job_id].update(changes)


def run_job(job_id, file_id, options):
    try:
        st=Settings.parse(options)
        in_path=WORKSPACE/f'{file_id}.source'
        if not in_path.exists(): raise PanoramaError('Исходник не найден')
        out_path=WORKSPACE/f'{job_id}.{st.fmt}'
        update_job(job_id,status='running',step='Подготовка')
        report=enhance(in_path,out_path,st,root=ROOT,notify=lambda m:update_job(job_id,step=m))
        preview_path=WORKSPACE/f'{job_id}.preview.jpg'
        update_job(job_id,step='Создание предпросмотра')
        make_preview(out_path,preview_path)
        update_job(job_id,status='done',step='Готово',report=report,
                   preview=f'/api/media/{job_id}.preview.jpg',
                   download=f'/api/media/{job_id}.{st.fmt}')
    except Exception as e:
        update_job(job_id,status='error',step='Ошибка',error=str(e))
        print(f'[Panorama Forge] Job {job_id} failed: {traceback.format_exc()}')


class Handler(BaseHTTPRequestHandler):
    server_version='PanoramaForge/0.1'

    def send_json(self, data, status=200):
        b=json.dumps(data,ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(b)))
        self.send_header('Cache-Control','no-store')
        self.end_headers()
        self.wfile.write(b)

    def send_file(self,path, filename=None):
        if not path.is_file():
            self.send_error(404,'Not found'); return
        self.send_response(200)
        self.send_header('Content-Type',mimetypes.guess_type(str(path))[0] or 'application/octet-stream')
        self.send_header('Content-Length',str(path.stat().st_size))
        self.send_header('Cache-Control','no-store')
        if filename:
            self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.end_headers()
        with path.open('rb') as f:
            while (chunk:=f.read(256*1024)):
                self.wfile.write(chunk)

    def is_local_origin(self):
        origin=self.headers.get('Origin','')
        if not origin: return True
        parsed=urllib.parse.urlparse(origin)
        return parsed.hostname in ('localhost','127.0.0.1') and parsed.port==self.server.server_port

    def do_GET(self):
        p=urllib.parse.urlparse(self.path).path
        if p=='/': return self.send_file(ROOT/'index.html')
        if p=='/api/status':
            return self.send_json({'version':'0.1.0','ai_ready':bool(locate_ai_exe(ROOT)),
                                   'ai_install':'INSTALL_AI_WINDOWS.bat','max_upload_mb':95})
        if p.startswith('/api/job/'):
            jid=p.split('/')[-1]
            with LOCK: j=JOBS.get(jid)
            return self.send_json(j if j else {'error':'Задача не найдена'},200 if j else 404)
        if p.startswith('/api/media/'):
            basename=p[len('/api/media/'):]
            if not basename or '/' in basename or '\\' in basename or '..' in basename:
                return self.send_error(400)
            suffix=Path(basename).suffix.lower()
            if suffix not in ('.jpg','.jpeg','.png','.webp'):
                return self.send_error(400)
            return self.send_file(WORKSPACE/basename,basename if '.preview.' not in basename else None)
        self.send_error(404,'Not found')

    def do_POST(self):
        if not self.is_local_origin():
            return self.send_json({'error':'Запросы с посторонних сайтов запрещены'},403)
        p=urllib.parse.urlparse(self.path).path
        size=int(self.headers.get('Content-Length','0') or 0)
        if size<=0 or size>MAX_UPLOAD:
            return self.send_json({'error':'Размер файла должен быть от 1 байта до 95 МБ'},413)
        if p=='/api/upload':
            if self.headers.get('Content-Type','').split(';')[0] not in ('image/png','image/jpeg','image/webp','image/tiff','application/octet-stream'):
                return self.send_json({'error':'Нужен файл PNG, JPEG, WebP или TIFF'},400)
            file_id=secrets.token_hex(12)
            path=WORKSPACE/f'{file_id}.source'
            try:
                with path.open('wb') as f:
                    remaining=size
                    while remaining:
                        chunk=self.rfile.read(min(256*1024,remaining))
                        if not chunk: raise PanoramaError('Файл загружен не полностью')
                        f.write(chunk); remaining-=len(chunk)
                with Image.open(path) as src:
                    img=to_pano_rgb(src)
                    dimensions=list(img.size)
                preview=WORKSPACE/f'{file_id}.preview.jpg'
                make_preview(path,preview)
                return self.send_json({'id':file_id,'dimensions':dimensions,'preview':f'/api/media/{file_id}.preview.jpg'})
            except Exception as e:
                path.unlink(missing_ok=True)
                return self.send_json({'error':str(e)},400)
        if p=='/api/process':
            if size>16*1024:
                return self.send_json({'error':'Слишком длинные параметры'},400)
            try:
                data=json.loads(self.rfile.read(size))
                file_id=data.get('file_id','')
                if not isinstance(file_id,str) or not file_id.isalnum() or len(file_id)!=24:
                    raise PanoramaError('Нет исходной панорамы')
                if not (WORKSPACE/f'{file_id}.source').exists():
                    raise PanoramaError('Исходный файл не найден')
                options=data.get('options',{})
                Settings.parse(options)
                jid=secrets.token_hex(12)
                with LOCK:
                    JOBS[jid]={'id':jid,'status':'queued','step':'Ожидает обработки'}
                POOL.submit(run_job,jid,file_id,options)
                return self.send_json(JOBS[jid],202)
            except (PanoramaError,ValueError,TypeError) as e:
                return self.send_json({'error':str(e)},400)
        self.send_error(404)

    def log_message(self,fmt,*args):
        if not self.path.startswith('/api/job/'):
            print('[HTTP]',fmt%args)


def cli():
    parser=argparse.ArgumentParser(description='Panorama Forge 360°: локальное улучшение панорам')
    sub=parser.add_subparsers(dest='command')
    serve=sub.add_parser('serve',help='Запустить интерфейс в браузере')
    serve.add_argument('--port',type=int,default=8787)
    serve.add_argument('--no-browser',action='store_true')
    run=sub.add_parser('enhance',help='Обработать панораму без браузера')
    run.add_argument('input',type=Path)
    run.add_argument('output',type=Path)
    run.add_argument('--scale',type=int,default=2,choices=[2,4])
    run.add_argument('--mode',choices=['precision','ai'],default='precision')
    run.add_argument('--sharpen',type=int,default=30)
    run.add_argument('--denoise',type=int,default=0)
    run.add_argument('--seam',type=int,default=48)
    run.add_argument('--model',default='realesrgan-x4plus')
    args=parser.parse_args()
    if args.command in (None,'serve'):
        port=getattr(args,'port',8787)
        httpd=ThreadingHTTPServer(('127.0.0.1',port),Handler)
        print(f'Panorama Forge started at http://127.0.0.1:{port}/')
        if not getattr(args,'no_browser',False):
            import threading
            threading.Timer(0.5,lambda:webbrowser.open(f'http://127.0.0.1:{port}/')).start()
        try: httpd.serve_forever()
        except KeyboardInterrupt: pass
        finally: httpd.server_close(); POOL.shutdown(wait=False)
    else:
        if not args.input.is_file(): parser.error('Входной файл не найден')
        fmt=args.output.suffix.lower().lstrip('.')
        if fmt=='jpeg':fmt='jpg'
        try:
            st=Settings.parse(dict(scale=args.scale,mode=args.mode,sharpen=args.sharpen,
                                   denoise=args.denoise,seam=args.seam,model=args.model,fmt=fmt))
            report=enhance(args.input,args.output,st,notify=lambda x:print(x,flush=True))
            print(json.dumps(report,ensure_ascii=False,indent=2))
        except PanoramaError as e:
            parser.error(str(e))


if __name__=='__main__':
    cli()
