import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine import Settings, PanoramaError, enhance, fix_seam, spherical_pad, seam_score, validate_pano, apply_zones


def generate(w=256, h=128):
    yy,xx=np.indices((h,w))
    a=np.zeros((h,w,3), dtype=np.uint8)
    a[:,:,0]=(128+100*np.cos(xx/w*2*np.pi)).astype(np.uint8)
    a[:,:,1]=(yy*1.6).astype(np.uint8)
    a[:,:,2]=((xx+yy)//3%256).astype(np.uint8)
    return Image.fromarray(a)


class EngineTests(unittest.TestCase):
    def test_spherical_padding_wrap_and_poles(self):
        src=generate();w,h=src.size
        out=np.array(spherical_pad(src,8,6));arr=np.asarray(src)
        # Each horizontal edge wraps exactly.
        self.assertTrue(np.array_equal(out[6,7],arr[0,w-1]))
        self.assertTrue(np.array_equal(out[6,8+w],arr[0,0]))
        # North pole crossing flips y and longitude by 180°.
        self.assertTrue(np.array_equal(out[5,8],arr[0,w//2]))
        self.assertTrue(np.array_equal(out[4,8],arr[1,w//2]))
        # South pole crossing flips y and longitude by 180°.
        self.assertTrue(np.array_equal(out[h+6,8],arr[h-1,w//2]))

    def test_seam_repair_reduces_error_and_keeps_center(self):
        a=np.asarray(generate()).copy()
        a[:,0,:]=5;a[:,-1,:]=250
        src=Image.fromarray(a);before=seam_score(src)
        after=fix_seam(src,32)
        self.assertGreater(before,150)
        self.assertLess(seam_score(after),2)
        self.assertTrue(np.array_equal(np.asarray(after)[:,80,:],a[:,80,:]))

    def test_precision_end_to_end(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'in.png';out=Path(tmp)/'out.png';generate().save(f)
            st=Settings.parse({'scale':2,'sharpen':50,'seam':48,'zones':[{'x':0.2,'y':0.2,'w':0.1,'h':0.2,'power':1.5}]})
            report=enhance(f,out,st)
            self.assertEqual(tuple(report['output']),(512,256))
            self.assertLess(report['seam_final'],2)
            self.assertTrue(out.is_file())
            with Image.open(out) as im:self.assertEqual(im.size,(512,256))

    def test_precision_x4_webp(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'in.png';out=Path(tmp)/'out.webp';generate().save(f)
            report=enhance(f,out,Settings.parse({'scale':4,'fmt':'webp','seam':0}))
            self.assertEqual(tuple(report['output']),(1024,512))
            with Image.open(out) as im:self.assertEqual(im.size,(1024,512))

    def test_reject_non_equirectangular(self):
        with self.assertRaises(PanoramaError):validate_pano(Image.new('RGB',(640,480)))

    def test_missing_ai_binary_is_explicit(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'in.png';out=Path(tmp)/'out.png';generate().save(f)
            with self.assertRaisesRegex(PanoramaError,'AI-движок'):
                enhance(f,out,Settings.parse({'mode':'ai'}),root=Path(tmp))

    def test_ai_adapter_with_mock_inference_engine(self):
        # Mock only the GPU executable. It verifies padding, dimensions and crop,
        # NOT the visual quality of a real Real-ESRGAN model.
        import os
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);ai=folder/'ai';ai.mkdir()
            fake=ai/'realesrgan-ncnn-vulkan'
            fake.write_text('#!'+sys.executable+'\n'
                'import sys\nfrom PIL import Image\n'
                'a=sys.argv\n'
                'im=Image.open(a[a.index("-i")+1])\n'
                'im.resize((im.width*4,im.height*4)).save(a[a.index("-o")+1])\n')
            fake.chmod(0o755)
            src=folder/'source.png';out=folder/'ai-result.png';generate().save(src)
            report=enhance(src,out,Settings.parse({'scale':2,'mode':'ai','sharpen':0}),root=folder)
            self.assertEqual(report['output'],[512,256])
            with Image.open(out) as im: self.assertEqual(im.size,(512,256))

    def test_bad_setting_rejected(self):
        for payload in ({'scale':5},{'mode':'imaginary'},{'fmt':'exe'},{'tile':10}):
            with self.assertRaises(PanoramaError):Settings.parse(payload)


if __name__=='__main__':unittest.main()
