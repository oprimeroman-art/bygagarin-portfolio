@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Panorama Forge — 360 Reconstruction Studio
where py >nul 2>&1
if %errorlevel%==0 (
 set "PY=py -3"
) else (
 where python >nul 2>&1
 if %errorlevel% neq 0 (
   echo Python 3 не установлен.
   echo Установи Python с https://www.python.org/downloads/windows/
   echo При установке включи Add Python to PATH.
   start "" "https://www.python.org/downloads/windows/"
   pause
   exit /b 1
 )
 set "PY=python"
)
%PY% -c "import PIL, numpy" >nul 2>&1
if errorlevel 1 (
 echo [Panorama Forge] Устанавливаем Pillow и numpy (один раз)...
 %PY% -m pip install -r requirements.txt
 if errorlevel 1 (
   echo Ошибка установки библиотек.
   pause
   exit /b 1
 )
)
echo [Panorama Forge] Откроется локальный редактор.
echo Оставь это окно открытым на время обработки панорам.
%PY% panorama_forge.py serve
if errorlevel 1 pause
