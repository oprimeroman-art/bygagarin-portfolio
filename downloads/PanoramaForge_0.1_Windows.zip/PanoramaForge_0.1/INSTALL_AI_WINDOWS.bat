@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Panorama Forge — Real-ESRGAN AI Installer
echo Установка официального Real-ESRGAN-ncnn-vulkan v0.2.0...
echo Для установки понадобится интернет и видеокарта с Vulkan.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_ai.ps1"
if errorlevel 1 (
 echo Ошибка установки. Подробности выше.
) else (
 echo AI-движок установлен. Перезапусти Panorama Forge.
)
pause
