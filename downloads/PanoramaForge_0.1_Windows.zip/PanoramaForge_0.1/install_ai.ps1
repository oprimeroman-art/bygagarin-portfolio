$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$url = 'https://github.com/xinntao/Real-ESRGAN-ncnn-vulkan/releases/download/v0.2.0/realesrgan-ncnn-vulkan-v0.2.0-windows.zip'
$expectedSha = '1bbbdb12d470af80b035c773682e144c6c2f6ece9210832a289af0a48ce3fa9a'
$tmp = Join-Path $env:TEMP ('PanoramaForge-AI-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tmp | Out-Null
try {
    $zip = Join-Path $tmp 'realesrgan.zip'
    Write-Host 'Загрузка архива разработчика...'
    Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
    $sha = (Get-FileHash -Path $zip -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($sha -ne $expectedSha) { throw "Контрольная сумма архива не совпала. Ожидали $expectedSha, получили $sha" }
    $unpack = Join-Path $tmp 'unpacked'
    Expand-Archive -Path $zip -DestinationPath $unpack -Force
    $exe = Get-ChildItem -Path $unpack -Filter 'realesrgan-ncnn-vulkan.exe' -Recurse | Select-Object -First 1
    if (-not $exe) { throw 'В официальном архиве не найден exe-файл' }
    $dest = Join-Path $root 'ai'
    New-Item -ItemType Directory -Path $dest -Force | Out-Null
    Copy-Item -Path (Join-Path $exe.Directory.FullName '*') -Destination $dest -Recurse -Force
    if (-not (Test-Path (Join-Path $dest 'realesrgan-ncnn-vulkan.exe'))) { throw 'Не удалось установить движок' }
    Write-Host 'Готово. AI-движок установлен в папку ai.'
} finally {
    Remove-Item -Path $tmp -Force -Recurse -ErrorAction SilentlyContinue
}
