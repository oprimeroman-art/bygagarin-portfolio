#!/bin/sh
cd "$(dirname "$0")" || exit 1
python3 -c "import PIL,numpy" 2>/dev/null || python3 -m pip install -r requirements.txt
python3 panorama_forge.py serve
